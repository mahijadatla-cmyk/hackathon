/*
 * ipcchat.c - Inter-Process Chat Application using IPC (Linux / POSIX)
 *
 * Two independent processes (User A and User B) chat with each other
 * through one of three IPC mechanisms chosen at start-up:
 *
 *   fifo : Named pipes (two FIFOs, one per direction)
 *   msgq : System V message queue (mtype addresses the receiver)
 *   shm  : POSIX shared memory + named semaphores (producer-consumer)
 *
 * Build : make
 * Run   : ./ipcchat <fifo|msgq|shm> <A|B>     (one terminal each)
 * Quit  : type /quit
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/mman.h>
#include <semaphore.h>

#define MSG_LEN   256
#define FIFO_A2B  "/tmp/ipcchat_a2b"
#define FIFO_B2A  "/tmp/ipcchat_b2a"
#define MQ_KEYFILE "/tmp/ipcchat_mq.key"
#define SHM_NAME  "/ipcchat_shm"

typedef enum { M_FIFO, M_MSGQ, M_SHM } Mode;

/* ---- one message on the wire (used by msgq and shm) ---- */
struct chat_msg { long mtype; char text[MSG_LEN]; };   /* mtype 1 -> A, 2 -> B */

/* ---- shared-memory layout: two one-slot mailboxes ---- */
struct shm_area { char box[2][MSG_LEN]; };             /* box[0] -> A, box[1] -> B */

static Mode  mode;
static int   me;              /* 0 = A, 1 = B */
static char  name[2] = {'A','B'};
static volatile sig_atomic_t running = 1;

/* fifo */
static int fd_in = -1, fd_out = -1;
/* msgq */
static int qid = -1;
/* shm */
static struct shm_area *shm;
static sem_t *s_full[2], *s_empty[2];

static void stamp(char *buf, size_t n) {
    time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
    strftime(buf, n, "%H:%M:%S", &tm);
}

/* ------------------------------------------------------------------ */
/*  Transport layer: send_msg / recv_msg hide the IPC mechanism        */
/* ------------------------------------------------------------------ */
static void ipc_init(void) {
    int peer = 1 - me;
    if (mode == M_FIFO) {
        mkfifo(FIFO_A2B, 0666); mkfifo(FIFO_B2A, 0666);
        /* O_RDWR avoids blocking on open until the peer arrives */
        fd_in  = open(me == 0 ? FIFO_B2A : FIFO_A2B, O_RDWR);
        fd_out = open(me == 0 ? FIFO_A2B : FIFO_B2A, O_RDWR);
        if (fd_in < 0 || fd_out < 0) { perror("open fifo"); exit(1); }
    } else if (mode == M_MSGQ) {
        int f = open(MQ_KEYFILE, O_CREAT | O_RDWR, 0666); if (f >= 0) close(f);
        key_t key = ftok(MQ_KEYFILE, 'C');
        qid = msgget(key, IPC_CREAT | 0666);
        if (qid < 0) { perror("msgget"); exit(1); }
    } else {
        int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
        if (fd < 0) { perror("shm_open"); exit(1); }
        if (ftruncate(fd, sizeof(struct shm_area)) < 0) { perror("ftruncate"); exit(1); }
        shm = mmap(NULL, sizeof *shm, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        if (shm == MAP_FAILED) { perror("mmap"); exit(1); }
        close(fd);
        const char *fn[2] = {"/ipcchat_full_a", "/ipcchat_full_b"};
        const char *en[2] = {"/ipcchat_empty_a", "/ipcchat_empty_b"};
        for (int i = 0; i < 2; i++) {            /* O_CREAT without O_EXCL: both sides share */
            s_full[i]  = sem_open(fn[i], O_CREAT, 0666, 0);
            s_empty[i] = sem_open(en[i], O_CREAT, 0666, 1);
            if (s_full[i] == SEM_FAILED || s_empty[i] == SEM_FAILED) { perror("sem_open"); exit(1); }
        }
    }
    (void)peer;
}

static void send_msg(const char *text) {
    int peer = 1 - me;
    if (mode == M_FIFO) {
        char line[MSG_LEN + 2]; int n = snprintf(line, sizeof line, "%s\n", text);
        if (write(fd_out, line, n) < 0) perror("write");
    } else if (mode == M_MSGQ) {
        struct chat_msg m; m.mtype = peer + 1;
        strncpy(m.text, text, MSG_LEN - 1); m.text[MSG_LEN - 1] = 0;
        if (msgsnd(qid, &m, strlen(m.text) + 1, 0) < 0) perror("msgsnd");
    } else {
        sem_wait(s_empty[peer]);                        /* wait until mailbox is free   */
        strncpy(shm->box[peer], text, MSG_LEN - 1); shm->box[peer][MSG_LEN - 1] = 0;
        sem_post(s_full[peer]);                         /* signal: message available    */
    }
}

/* returns 1 on message, 0 on shutdown */
static int recv_msg(char *out) {
    if (mode == M_FIFO) {
        static char buf[MSG_LEN * 2]; static size_t have = 0;
        for (;;) {
            char *nl = memchr(buf, '\n', have);
            if (nl) {
                size_t len = nl - buf; if (len >= MSG_LEN) len = MSG_LEN - 1;
                memcpy(out, buf, len); out[len] = 0;
                memmove(buf, nl + 1, have - (nl - buf) - 1); have -= (nl - buf) + 1;
                return 1;
            }
            ssize_t r = read(fd_in, buf + have, sizeof buf - have);
            if (r <= 0) return 0;
            have += r;
        }
    } else if (mode == M_MSGQ) {
        struct chat_msg m;
        if (msgrcv(qid, &m, MSG_LEN, me + 1, 0) < 0) return 0;
        strcpy(out, m.text); return 1;
    } else {
        if (sem_wait(s_full[me]) < 0) return 0;         /* block until message arrives  */
        strcpy(out, shm->box[me]);
        sem_post(s_empty[me]);                          /* mailbox free again           */
        return 1;
    }
}

static void ipc_cleanup(int destroy) {
    if (mode == M_FIFO) { close(fd_in); close(fd_out); if (destroy) { unlink(FIFO_A2B); unlink(FIFO_B2A); } }
    else if (mode == M_MSGQ) { if (destroy) { msgctl(qid, IPC_RMID, NULL); unlink(MQ_KEYFILE); } }
    else {
        const char *fn[2] = {"/ipcchat_full_a", "/ipcchat_full_b"};
        const char *en[2] = {"/ipcchat_empty_a", "/ipcchat_empty_b"};
        munmap(shm, sizeof *shm);
        for (int i = 0; i < 2; i++) { sem_close(s_full[i]); sem_close(s_empty[i]); }
        if (destroy) { shm_unlink(SHM_NAME); for (int i = 0; i < 2; i++) { sem_unlink(fn[i]); sem_unlink(en[i]); } }
    }
}

/* ------------------------------------------------------------------ */
/*  Receiver thread: prints incoming messages                          */
/* ------------------------------------------------------------------ */
static void *receiver(void *arg) {
    (void)arg; char msg[MSG_LEN], ts[16];
    while (running && recv_msg(msg)) {
        stamp(ts, sizeof ts);
        if (strcmp(msg, "/quit") == 0) {
            printf("\r\033[K[%s] User %c left the chat.\n", ts, name[1 - me]);
            running = 0; ipc_cleanup(1);
            printf("Chat closed. IPC resources released.\n"); fflush(stdout);
            _exit(0);
        }
        printf("\r\033[K[%s] \033[1;32mUser %c\033[0m: %s\n", ts, name[1 - me], msg);
        printf("You (%c)> ", name[me]); fflush(stdout);
    }
    return NULL;
}

static void on_sigint(int s) { (void)s; running = 0; }

int main(int argc, char **argv) {
    if (argc != 3 || (strcmp(argv[2], "A") && strcmp(argv[2], "B")) ||
        (strcmp(argv[1], "fifo") && strcmp(argv[1], "msgq") && strcmp(argv[1], "shm"))) {
        fprintf(stderr, "Usage: %s <fifo|msgq|shm> <A|B>\n", argv[0]); return 1;
    }
    mode = !strcmp(argv[1], "fifo") ? M_FIFO : !strcmp(argv[1], "msgq") ? M_MSGQ : M_SHM;
    me = argv[2][0] == 'A' ? 0 : 1;
    signal(SIGINT, on_sigint); signal(SIGPIPE, SIG_IGN);

    ipc_init();
    printf("=== IPC Chat | mechanism: %s | you are User %c (PID %d) ===\n"
           "Type a message and press Enter. Type /quit to exit.\n", argv[1], name[me], getpid());

    pthread_t th; pthread_create(&th, NULL, receiver, NULL);

    char line[MSG_LEN];
    printf("You (%c)> ", name[me]); fflush(stdout);
    while (running && fgets(line, sizeof line, stdin)) {
        line[strcspn(line, "\n")] = 0;
        if (!*line) { printf("You (%c)> ", name[me]); fflush(stdout); continue; }
        send_msg(line);
        if (strcmp(line, "/quit") == 0) { running = 0; break; }
        printf("You (%c)> ", name[me]); fflush(stdout);
    }
    if (running) send_msg("/quit");           /* EOF on stdin: tell the peer */
    running = 0;
    usleep(200000);                           /* let the peer drain the last message */
    ipc_cleanup(1);
    printf("\nChat closed. IPC resources released.\n");
    return 0;
}
