# Inter-Process Chat Application Using IPC

Two-way chat between **independent processes** (User A / User B) using three IPC mechanisms.

| Mode  | IPC mechanism                              | Synchronisation                    |
|-------|--------------------------------------------|------------------------------------|
| fifo  | Named pipes (2 FIFOs, one per direction)   | Kernel blocking read/write         |
| msgq  | System V message queue (`msgget/snd/rcv`)  | `mtype` selects the receiver       |
| shm   | POSIX shared memory + named semaphores     | Producer-consumer (full/empty sem) |

## Build & Run (Linux / WSL / Ubuntu)
```bash
make
# Terminal 1                # Terminal 2
./ipcchat fifo A            ./ipcchat fifo B
./ipcchat msgq A            ./ipcchat msgq B
./ipcchat shm  A            ./ipcchat shm  B
```
Type a message + Enter to send. `/quit` ends the chat and releases all IPC resources.
`make clean` removes leftovers if a process was killed.

Demo helper: `./demo.sh <fifo|msgq|shm>` runs a scripted two-process conversation.
