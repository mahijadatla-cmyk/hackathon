#!/bin/bash
# Scripted live demo: runs User A and User B as two independent processes.
M=${1:-fifo}; make -s || exit 1
(sleep 1; echo "Hello B, this is A over $M"; sleep 2; echo "Sending file report... done"; sleep 3; echo "/quit") | ./ipcchat $M A &
(sleep 2; echo "Hi A! B received your message"; sleep 2; echo "Great, IPC works both ways"; sleep 4) | ./ipcchat $M B &
wait
